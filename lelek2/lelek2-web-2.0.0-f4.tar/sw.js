// Minimal hand-written service worker (F2-DESIGN.md: "service worker:
// cache-first pro statiku (verzované názvy z Vite), network-only pro
// /api"). No vite-plugin-pwa / Workbox — a few lines cover the two rules
// this app needs and keep the bundle smaller.
const CACHE_NAME = "lelek-static-v1";

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== self.location.origin) return;

  // Never cache the API — always hits the device.
  if (url.pathname.startsWith("/api/")) return;

  // Vite's build output is content-hashed (/assets/*-<hash>.js|css) — safe
  // to serve cache-first forever. Everything else (index.html, manifest,
  // icons, this file) is network-first so a redeploy is picked up promptly,
  // falling back to cache when the device is unreachable.
  const isHashedAsset = /\/assets\/.+-[a-zA-Z0-9_-]{6,}\.\w+$/.test(url.pathname);

  if (isHashedAsset) {
    event.respondWith(
      caches.match(event.request).then(
        (cached) =>
          cached ||
          fetch(event.request).then((res) => {
            const copy = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
            return res;
          }),
      ),
    );
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((res) => {
        const copy = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        return res;
      })
      .catch(() => caches.match(event.request)),
  );
});
